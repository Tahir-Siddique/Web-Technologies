PPSC is a word to test

                
                