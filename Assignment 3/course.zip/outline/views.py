from django.shortcuts import render
from . import util

# Create your views here.
def index(request):
    return render(request, "outline/index.html", {
        "topics": util.list_topics()
    })