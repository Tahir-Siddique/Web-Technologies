# Django

Django is a web framework written using [Python](/outline/Python) that allows for the design of web applications that generate [HTML](/outline/HTML) dynamically.
